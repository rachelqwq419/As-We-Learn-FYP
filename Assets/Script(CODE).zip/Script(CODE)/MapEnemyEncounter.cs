using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class MapEnemyEncounter : MonoBehaviour
{
    [Header("怪獸設定")]
    public string Subject = "Math";
    public int Level = 1;

    [Header("UI 連結")]
    public TextMeshProUGUI nameLabel;

    private void Start()
    {
        // 1. 攞返同一個物件上面嘅 EnemyData (入面有怪獸名) [cite: 316]
        EnemyData enemyData = GetComponent<EnemyData>();

        if (nameLabel != null)
        {
            string mName = (enemyData != null && !string.IsNullOrEmpty(enemyData.monsterName))
                           ? enemyData.monsterName
                           : "Monster";

            // 2. 🔥 使用 \n 嚟分行
            // 第一行：科目 Lv.等級
            // 第二行：怪獸名
            nameLabel.text = $"{Subject} Lv.{Level}\n{mName}";
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log($"撞到怪獸！進入戰鬥：{Subject} Lv.{Level}");

            // 寫入資料供 BattleScene 使用 [cite: 153]
            GameData.chosenSubject = Subject;
            GameData.chosenLevel = Level;

            SceneManager.LoadScene("BattleScene");
        }
    }
}