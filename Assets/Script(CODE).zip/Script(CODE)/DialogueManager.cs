using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

// 💡 定義每一句對話包含嘅嘢
[System.Serializable]
public class DialogueLine
{
    public string name;            // 邊個講？(Kael / Mia / Bella)
    public Sprite portrait;        // 講嗰個人嘅樣
    public AudioClip voiceClip;    // 🔥 AI 配音檔
    [TextArea(3, 10)]
    public string sentence;        // 講啲咩？
}

public class DialogueManager : MonoBehaviour
{
    public static DialogueManager instance;

    [Header("UI 引用")]
    public GameObject dialoguePanel;
    public TextMeshProUGUI nameText;
    public TextMeshProUGUI dialogueText;
    public Image portraitImage;

    [Header("音效組件")]
    public AudioSource voiceSource;      // 🔥 拖入用嚟播配音嘅 AudioSource

    [Header("對話內容")]
    public DialogueLine[] dialogueLines;

    private int index;

    void Awake()
    {
        instance = this;
    }

    void OnEnable()
    {
        index = 0;
        if (dialogueLines.Length > 0)
        {
            DisplayNextSentence();
        }
    }

    void Update()
    {
        // 撳 E 或者左鍵跳下一句
        if (Input.GetKeyDown(KeyCode.E) || Input.GetMouseButtonDown(0))
        {
            DisplayNextSentence();
        }
    }

    public void DisplayNextSentence()
    {
        if (index < dialogueLines.Length)
        {
            // 1. 更新文字同頭像
            nameText.text = dialogueLines[index].name;
            dialogueText.text = dialogueLines[index].sentence;
            portraitImage.sprite = dialogueLines[index].portrait;

            // 2. 🔥 播放 AI 配音
            if (voiceSource != null && dialogueLines[index].voiceClip != null)
            {
                voiceSource.Stop(); // 確保唔會同上一句叠埋一齊
                voiceSource.clip = dialogueLines[index].voiceClip;
                voiceSource.Play();
            }

            index++;
        }
        else
        {
            EndDialogue();
        }
    }

    void EndDialogue()
    {
        if (voiceSource != null) voiceSource.Stop(); // 完咗就收聲
        dialoguePanel.SetActive(false);
        Time.timeScale = 1; // 恢復遊戲
    }
}