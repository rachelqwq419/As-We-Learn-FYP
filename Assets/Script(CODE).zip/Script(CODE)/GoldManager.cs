using UnityEngine;

public class GoldManager : MonoBehaviour
{
    public static GoldManager instance;
    public int gold;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }

        LoadGold();
    }

    public void AddGold(int amount)
    {
        gold += amount;
        SaveGold();
    }

    public void ReduceGold(int amount)
    {
        gold -= amount;
        if (gold <= 0)
        {
            gold = 0;
        }

        SaveGold();
    }

    private void OnApplicationQuit()
    {
        SaveGold();
    }

    public void SaveGold()
    {
        // 🔥 1. 攞返 LoginManager 登入時記低咗嘅帳號名
        string currentUser = PlayerPrefs.GetString("CurrentUser", "UnknownUser");

        // 🔥 2. 拼出專屬存檔 Key，例如 "Gold_Peter" 或 "Gold_Mary"
        string saveKey = "Gold_" + currentUser;

        // 3. 儲存落專屬櫃桶
        PlayerPrefs.SetInt(saveKey, gold);
        PlayerPrefs.Save(); // Ensure it's written to disk
    }

    public void LoadGold()
    {
        // 🔥 1. 攞返 LoginManager 登入時記低咗嘅帳號名
        string currentUser = PlayerPrefs.GetString("CurrentUser", "UnknownUser");

        // 🔥 2. 拼出專屬存檔 Key
        string saveKey = "Gold_" + currentUser;

        // 🔥 3. 讀取專屬櫃桶嘅錢，如果係新帳號搵唔到，就預設俾 30 蚊！
        gold = PlayerPrefs.GetInt(saveKey, 30);
    }
}